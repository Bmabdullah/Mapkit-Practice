//
//  ViewController.swift
//  Map kit Demo
//
//  Created by AL Mustakim on 26/5/20.
//  Copyright © 2020 AL Mustakim. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController,CLLocationManagerDelegate {
    
    let locationManager = CLLocationManager()

    @IBOutlet weak var mapLocationView: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        checklocationService()
    }
    
    func SetupLocationManager(){
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    func checklocationService(){
        if CLLocationManager.locationServicesEnabled(){
            // code for location manager
            SetupLocationManager()
            checkLocationAuthorigation()
        }
        else {
            print("your location servise is not enabled")
        }
    }
    
    
    func checkLocationAuthorigation() {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedWhenInUse:
            //do map stuff
            mapLocationView.showsUserLocation = true
            centerViewUserLocation()
            locationManager.startUpdatingLocation()
            break
        case .authorizedAlways:
            break
        case .denied:
            //alert how to turn on permission
            break
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted:
            //alert letting them whats up
            break
        @unknown default: break
            
        }
    }
    
    let regionmeter : Double = 100
    
    func centerViewUserLocation(){
        if let location = locationManager.location?.coordinate{
            let region = MKCoordinateRegion.init(center: location, latitudinalMeters: regionmeter, longitudinalMeters: regionmeter)
            mapLocationView.setRegion(region, animated: true)
        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // wi iwll code here
        guard let location = locations.last else {return}
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion.init(center: center, latitudinalMeters: regionmeter, longitudinalMeters: regionmeter)
        mapLocationView.setRegion(region, animated: true)
    }
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        checkLocationAuthorigation()
    }
    
    


}

